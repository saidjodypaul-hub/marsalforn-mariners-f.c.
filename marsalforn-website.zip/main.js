function renderPlayers(players, containerId, isNursery=false) {
    const container = document.getElementById(containerId);
    container.innerHTML = "";
    players.forEach(player => {
        const div = document.createElement("div");
        div.classList.add("player");
        div.innerHTML = `
            <img src="${player.img}" alt="${player.name}">
            <h3>${player.name}</h3>
            <p>${isNursery ? "Age: "+player.age : player.position}</p>
        `;
        container.appendChild(div);
    });
}
renderPlayers(firstTeam, "first-team-players");
renderPlayers(nursery, "nursery-players", true);