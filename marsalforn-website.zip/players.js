const firstTeam = [
    { name: "John Doe", position: "Forward", img: "images/player1.jpg" },
    { name: "Mike Smith", position: "Midfielder", img: "images/player2.jpg" }
];
const nursery = [
    { name: "Alex Brown", age: 8, img: "images/kid1.jpg" },
    { name: "Emma White", age: 10, img: "images/kid2.jpg" }
];